
# 📝 Dockerized Task Manager App

A simple yet powerful task manager web application built with **React (frontend)** and **Flask (backend)**. The entire app is containerized using **Docker** for seamless development and deployment.

---

## 🚀 Features

- ✅ Add, view, and delete tasks
- 🎨 Intuitive and responsive UI
- 📦 Full Docker support (frontend + backend)
- 🔁 Auto task ID assignment
- 💡 Task status options: `todo`, `in progress`, `done`
- 🚨 Graceful error handling

---

## 🗂 Sample Task Data

```json
[
  {"id": 1, "title": "Finish report", "description": "Complete Q3 summary", "status": "todo"},
  {"id": 2, "title": "Team meeting", "description": "Discuss project goals", "status": "done"}
]
```

---

## 🧪 Run with Docker Compose

```bash
docker-compose up --build
```

- Frontend: http://localhost:3000  
- Backend API: http://localhost:5000/tasks

---

## 📌 Future Enhancements

- 🔄 Edit task functionality
- 📊 Task filtering by status
- 🌐 Persistent storage with database
- ☁️ Deploy to Render/Heroku

---

## 💻 Screenshots

> UI displays task list and input fields with real-time updates. Easy to use, even on mobile!

---

## 📁 Project Structure

```
dockerized-task-app/
├── backend/
├── frontend/
└── docker-compose.yml
```

---

Made with ❤️ using React, Flask & Docker.
