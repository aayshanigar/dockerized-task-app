
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

tasks = [
    {"id": 1, "title": "Finish report", "description": "Complete Q3 summary", "status": "todo"},
    {"id": 2, "title": "Team meeting", "description": "Discuss project goals", "status": "done"}
]

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks)

@app.route('/tasks', methods=['POST'])
def add_task():
    task = request.json
    task["id"] = max([t["id"] for t in tasks] or [0]) + 1
    tasks.append(task)
    return jsonify(task), 201

@app.route('/tasks/<int:id>', methods=['DELETE'])
def delete_task(id):
    global tasks
    tasks = [t for t in tasks if t["id"] != id]
    return '', 204

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
