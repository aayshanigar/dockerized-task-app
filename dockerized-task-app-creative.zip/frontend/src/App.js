
import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState({ title: '', description: '', status: 'todo' });

  useEffect(() => {
    fetch('http://localhost:5000/tasks')
      .then(res => res.json())
      .then(setTasks)
      .catch(() => alert('Failed to load tasks'));
  }, []);

  const addTask = () => {
    fetch('http://localhost:5000/tasks', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(newTask)
    }).then(res => res.json()).then(task => {
      setTasks([...tasks, task]);
      setNewTask({ title: '', description: '', status: 'todo' });
    });
  };

  const deleteTask = (id) => {
    fetch(`http://localhost:5000/tasks/${id}`, { method: 'DELETE' })
      .then(() => setTasks(tasks.filter(t => t.id !== id)));
  };

  return (
    <div className="App">
      <h1>Task Manager</h1>
      <input value={newTask.title} onChange={e => setNewTask({...newTask, title: e.target.value})} placeholder="Title" />
      <input value={newTask.description} onChange={e => setNewTask({...newTask, description: e.target.value})} placeholder="Description" />
      <select value={newTask.status} onChange={e => setNewTask({...newTask, status: e.target.value})}>
        <option>todo</option>
        <option>in progress</option>
        <option>done</option>
      </select>
      <button onClick={addTask}>Add Task</button>

      <ul>
        {tasks.map(task => (
          <li key={task.id}>
            <b>{task.title}</b> - {task.description} [{task.status}]
            <button onClick={() => deleteTask(task.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
