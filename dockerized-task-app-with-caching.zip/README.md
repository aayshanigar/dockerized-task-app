
# 📝 Dockerized Task Manager App with Caching

This web app uses **React (frontend)** and **Flask (backend)** and is fully containerized using **Docker**.

---

## 🚀 Features

- ✅ Add, view, delete tasks
- 🗃️ Caching using `localStorage`
- 📦 Dockerized frontend and backend
- 💡 Task status: todo, in progress, done
- 🔄 Manual cache refresh button

---

## ⚡ How Caching Works

- On load, the app checks `localStorage` for cached task data.
- If available, it loads tasks from cache. Otherwise, it fetches from the backend.
- When tasks are added or deleted, both UI state and localStorage are updated.
- A **🔄 Refresh Task Cache** button allows you to clear the cache manually and reload tasks from the server.

---

## 🧪 Run with Docker Compose

```bash
docker-compose up --build
```

---

## 📂 Structure

- `frontend/`: React app
- `backend/`: Flask API
- `docker-compose.yml`: Compose config

---

Made with ❤️ using React, Flask, and Docker.
